import 'package:flutter/material.dart';

const Color buttonColor=Color(0xff48BEE2);
const Color secondButtonColor=Color(0xffECF1FA);
const Color gradientColor=Color(0xff27bdea);
const Color textColor=Color(0xff263441);