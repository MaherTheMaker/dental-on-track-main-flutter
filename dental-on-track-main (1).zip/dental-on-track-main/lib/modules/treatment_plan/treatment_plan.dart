import 'package:flutter/material.dart';

import '../../config/size_config.dart';

class TreatmentPlans extends StatelessWidget {
  const TreatmentPlans({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    SizeConfig().init(context);
    return Scaffold(
      
    );
  }
}
