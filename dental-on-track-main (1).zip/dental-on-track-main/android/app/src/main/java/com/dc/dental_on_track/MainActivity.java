package com.dc.dental_on_track;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
